package es.um.redes.nanoChat.messageFV;

public class NCSendMessage {
}
